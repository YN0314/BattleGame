// 演出:ヒット火花と画面揺れ。ゲームの判定には影響しない。
(function () {
  'use strict';

  const sparks = [];
  let shakeMag = 0;
  let shakeLeft = 0;

  const RADII = [3, 6, 8, 8, 7, 5, 4, 2];

  function reset() {
    sparks.length = 0;
    shakeMag = 0;
    shakeLeft = 0;
  }

  function spawnHit(x, y, strong) {
    sparks.push({ x: Math.round(x), y: Math.round(y), age: 0, strong: !!strong });
    shake(Game.Config.display.effects.shakeHit, Game.Config.display.effects.shakeFrames);
  }

  // ガード火花:小さく青白い。画面は揺らさない
  function spawnGuard(x, y) {
    sparks.push({ x: Math.round(x), y: Math.round(y), age: 0, guard: true });
  }

  function shake(mag, frames) {
    shakeMag = mag;
    shakeLeft = frames;
  }

  function update() {
    for (let i = sparks.length - 1; i >= 0; i--) {
      sparks[i].age++;
      if (sparks[i].age >= Game.Config.display.effects.sparkFrames) sparks.splice(i, 1);
    }
    if (shakeLeft > 0) shakeLeft--;
  }

  // 画面揺れの現在のずれ(整数ピクセル)
  function offset() {
    if (shakeLeft <= 0) return { x: 0, y: 0 };
    const m = shakeMag;
    return {
      x: Math.round((Math.random() * 2 - 1) * m),
      y: Math.round((Math.random() * 2 - 1) * m)
    };
  }

  function draw(ctx) {
    sparks.forEach(function (s) {
      const r = RADII[Math.min(s.age, RADII.length - 1)];
      const x = s.x, y = s.y;
      if (s.guard) {
        // 十字を細くした青白い火花
        const gr = Math.max(2, Math.round(r * 0.7));
        ctx.fillStyle = '#9fd8ff';
        ctx.fillRect(x - gr, y, gr * 2 + 1, 1);
        ctx.fillRect(x, y - gr, 1, gr * 2 + 1);
        if (s.age < 4) {
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(x - 1, y - 1, 3, 3);
        }
        return;
      }
      ctx.fillStyle = s.strong ? '#ff9a4a' : '#fff0a0';
      ctx.fillRect(x - r, y - 1, r * 2 + 1, 3);
      ctx.fillRect(x - 1, y - r, 3, r * 2 + 1);
      const d = Math.floor(r * 0.7);
      for (let k = 2; k <= d; k++) {
        ctx.fillRect(x + k - 1, y + k - 1, 2, 2);
        ctx.fillRect(x - k - 1, y + k - 1, 2, 2);
        ctx.fillRect(x + k - 1, y - k - 1, 2, 2);
        ctx.fillRect(x - k - 1, y - k - 1, 2, 2);
      }
      if (s.age < 5) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(x - 2, y - 2, 5, 5);
      }
    });
  }

  Game.Render.Effects = {
    reset: reset, spawnHit: spawnHit, spawnGuard: spawnGuard, shake: shake,
    update: update, offset: offset, draw: draw
  };
})();
