// 技のデータ。数値を変えてリロードすれば調整できる。
//   startup        : 発生(攻撃判定が出るまでのフレーム数)
//   active         : 持続(攻撃判定が出ているフレーム数)
//   recovery       : 硬直(判定が消えたあと動けないフレーム数)。ジャンプ攻撃は着地まで続くため使わない
//   damage         : ダメージ
//   hitstun        : 当たった相手ののけぞりフレーム数
//   knockback      : 当たった相手が後ろへ押される初速(px/フレーム)
//   hitstop        : ヒット時に両者が止まるフレーム数(ガードされたときは少し短くなる)
//   blockstun      : ガードされたときの相手のガード硬直フレーム数
//   blockKnockback : ガードされたときの相手が押される初速(px/フレーム)
//   knockdown      : true なら、当たった相手はダウンする
//   hitbox         : 攻撃判定の箱。足元の中央が原点で、右向きの場合の座標(左向きは自動で反転)。yは上が負
//   level          : ガードのされ方
//                    'high' = 上段(立ちガードのみ可) / 'low' = 下段(しゃがみガードのみ可) / 'mid' = 中段(どちらでも可)
Game.Config.moves = {
  standPunch: {
    startup: 4, active: 3, recovery: 8,
    damage: 5, hitstun: 14, knockback: 2.2, hitstop: 5,
    blockstun: 10, blockKnockback: 1.6,
    hitbox: { x: 6, y: -40, w: 20, h: 8 }, level: 'mid'
  },
  standKick: {
    startup: 7, active: 4, recovery: 12,
    damage: 8, hitstun: 18, knockback: 3.0, hitstop: 7,
    blockstun: 13, blockKnockback: 2.2,
    hitbox: { x: 4, y: -33, w: 24, h: 10 }, level: 'mid'
  },
  crouchPunch: {
    startup: 5, active: 3, recovery: 8, crouch: true,
    damage: 4, hitstun: 13, knockback: 1.8, hitstop: 5,
    blockstun: 9, blockKnockback: 1.4,
    hitbox: { x: 6, y: -23, w: 20, h: 8 }, level: 'mid'
  },
  crouchKick: {
    startup: 7, active: 4, recovery: 14, crouch: true,
    damage: 6, hitstun: 18, knockback: 2.6, hitstop: 6,
    blockstun: 13, blockKnockback: 2.0, knockdown: true,
    hitbox: { x: 2, y: -9, w: 25, h: 8 }, level: 'low'
  },
  jumpPunch: {
    startup: 5, active: 6, recovery: 0, air: true,
    damage: 6, hitstun: 16, knockback: 2.2, hitstop: 5,
    blockstun: 12, blockKnockback: 1.6,
    hitbox: { x: 4, y: -37, w: 21, h: 9 }, level: 'high'
  },
  jumpKick: {
    startup: 6, active: 8, recovery: 0, air: true,
    damage: 8, hitstun: 18, knockback: 2.8, hitstop: 6,
    blockstun: 14, blockKnockback: 2.0,
    hitbox: { x: 2, y: -27, w: 24, h: 10 }, level: 'high'
  },

  // ---- 必殺技(コマンドは input.config.js の commands) ----
  // 波動拳風:startup のフレームで飛び道具を出す。その後 recovery フレーム動けない。
  //   projectile: speed=速さ(px/フレーム) offsetX/offsetY=出る位置 w/h=当たりの大きさ
  //               以降は通常技と同じ(damage, hitstun, knockback, hitstop, blockstun, blockKnockback, level)
  fireball: {
    special: true,
    startup: 12, active: 0, recovery: 22,
    projectile: {
      speed: 3.2, offsetX: 20, offsetY: -33, w: 16, h: 12,
      damage: 10, hitstun: 18, knockback: 3.0, hitstop: 6,
      blockstun: 14, blockKnockback: 2.4, level: 'mid'
    }
  },
  // 昇竜拳風:startup のフレームで飛び上がる。
  //   invuln=技の出始めの無敵フレーム数  launch=飛び上がりの速さ(vy:上向きが負, vx:前へ)
  //   active=上昇中に攻撃判定が出ているフレーム数  landRecovery=着地後に動けないフレーム数
  uppercut: {
    special: true,
    startup: 3, active: 10, recovery: 0,
    invuln: 6, launch: { vy: -7.4, vx: 1.6 }, landRecovery: 24,
    damage: 14, hitstun: 20, knockback: 2.6, hitstop: 8,
    blockstun: 18, blockKnockback: 2.4, knockdown: true,
    hitbox: { x: 0, y: -58, w: 22, h: 46 }, level: 'mid'
  }
};
