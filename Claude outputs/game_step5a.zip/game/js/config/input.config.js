// 入力の割り当て。キーは KeyboardEvent.code(物理的なキー位置)で指定する。
Game.Config.input = {
  keyboard: [
    // 1P
    { up: ['KeyW'], down: ['KeyS'], left: ['KeyA'], right: ['KeyD'],
      punch: ['KeyF'], kick: ['KeyG'], start: ['Enter'] },
    // 2P
    { up: ['ArrowUp'], down: ['ArrowDown'], left: ['ArrowLeft'], right: ['ArrowRight'],
      punch: ['KeyK'], kick: ['KeyL'], start: [] }
  ],

  // コントローラー(標準配置の機種を基準にしたボタン番号)
  gamepad: {
    deadzone: 0.5,                              // スティックをデジタル入力とみなすしきい値
    dpad: { up: 12, down: 13, left: 14, right: 15 },
    punch: [2, 3],                              // Xbox: X, Y / PlayStation: □, △
    kick: [0, 1],                               // Xbox: A, B / PlayStation: ×, ○
    start: [9]
  },

  historyFrames: 60,                            // 入力履歴の保持フレーム数(必殺技のコマンド判定用)

  // 必殺技のコマンド。方向は向きに対して相対的なテンキー番号(6=前, 4=後ろ, 2=下, 3=前下)。
  // motions の各項目は「各段階で許される方向番号」の並び。どれか1つに一致すれば成立。
  // 出すにはコマンドのあとパンチを押す。
  commands: {
    windowFrames: 18,                           // コマンド全体を入力できる時間(フレーム)
    leniencyFrames: 8,                          // コマンドの最後の方向からパンチまでの猶予(フレーム)

    // 波動拳風 ↓↘→ + パンチ(キーボード向けに ↓→ でも出る)
    fireball: { motions: [[[2], [3], [6]], [[2], [6]]] },
    // 昇竜拳風 →↓↘ + パンチ
    uppercut: { motions: [[[6], [2], [3]]] }
  }
};
