// キャラクター。状態機械と移動、攻撃、必殺技を持つ。描画には一切触れない。
// 状態:idle(待機) walk(歩く) jump(ジャンプ) crouch(しゃがみ)
//       attack(地上攻撃) jumpattack(空中攻撃) special(必殺技) landing(必殺技後の着地硬直)
//       hitstun(のけぞり) blockstun(ガード硬直) down(ダウン) getup(起き上がり) ko(敗北)
(function () {
  'use strict';

  class Fighter {
    constructor(opts) {
      this.index = opts.index || 0;           // 1P=0 / 2P=1(入力履歴の参照に使う)
      this.x = opts.x;                        // 体の中心X
      this.y = Game.Config.display.floorY;    // 足元のY(大きいほど下)
      this.vx = 0;
      this.vy = 0;
      this.facing = opts.facing;              // 1:右向き / -1:左向き
      this.palette = opts.palette;            // 0:1P色 / 1:2P色
      this.state = 'idle';
      this.stateFrame = 0;                    // 現在の状態になってからのフレーム数
      this.onGround = true;

      this.health = Game.Config.game.fighter.maxHealth;
      this.move = null;                       // 出している技の名前(moves.config のキー)
      this.attackFrame = 0;                   // 技を出してからのフレーム数
      this.hitDone = false;                   // この技がすでに当たったか(多段ヒット防止)
      this.airAttackUsed = false;             // このジャンプで空中攻撃を出したか
      this.stunFrames = 0;                    // のけぞり・ガード硬直・着地硬直の長さ
      this.wallPush = 0;                      // 画面端で動けなかった分(相手を押し返すのに使う)
      this.backHeld = false;                  // 相手と反対方向を押しているか(ガードの条件)
      this.downHeld = false;                  // 下を押しているか(しゃがみガードの条件)
      this.guardCrouch = false;               // しゃがみガードで受けたか(ポーズと高さに使う)
    }

    get moveData() {
      return this.move ? Game.Config.moves[this.move] : null;
    }

    // 当たり判定に使う高さ
    get height() {
      const P = Game.Config.physics;
      const m = this.moveData;
      const crouching = this.state === 'crouch' || this.state === 'landing' ||
        (this.state === 'attack' && m && m.crouch) ||
        (this.state === 'blockstun' && this.guardCrouch);
      return crouching ? P.crouchHeight : P.standHeight;
    }

    // 攻撃を受けられる状態か(ダウン中や、必殺技の出始めの無敵中は受けない)
    get vulnerable() {
      if (this.state === 'down' || this.state === 'getup' || this.state === 'ko') return false;
      if (this.state === 'special') {
        const m = this.moveData;
        if (m && m.invuln && this.attackFrame < m.invuln) return false;
      }
      return true;
    }

    // 攻撃判定が出ているか
    get attackActive() {
      const m = this.moveData;
      if (!m || this.hitDone || !m.hitbox) return false;
      if (this.state !== 'attack' && this.state !== 'jumpattack' && this.state !== 'special') return false;
      return this.attackFrame >= m.startup && this.attackFrame < m.startup + m.active;
    }

    setState(s) {
      if (this.state !== s) {
        this.state = s;
        this.stateFrame = 0;
      }
    }

    // input: Game.Core.Input.get(i) の戻り値 / opponent: 相手の Fighter
    update(input, opponent) {
      const P = Game.Config.physics;
      const h = input.held;
      this.stateFrame++;
      this.wallPush = 0;
      // ガードの条件は毎フレームの入力で決まる(攻撃を受けた瞬間に後ろを押していればガード)
      this.backHeld = this.facing > 0 ? h.left : h.right;
      this.downHeld = h.down;

      switch (this.state) {
        case 'hitstun': case 'blockstun': case 'down': case 'getup': case 'ko':
          this.updateDamaged();
          return;
        case 'attack':
          this.updateGroundAttack();
          return;
        case 'jumpattack':
          this.attackFrame++;
          this.stepAir();
          return;
        case 'special':
          this.updateSpecial();
          return;
        case 'landing':
          this.vx = 0;
          if (this.stateFrame >= this.stunFrames) this.setState('idle');
          return;
      }

      if (this.onGround) {
        // 地上では常に相手の方を向く
        if (opponent.x > this.x) this.facing = 1;
        else if (opponent.x < this.x) this.facing = -1;

        const special = h.up ? null : this.detectSpecial(input);
        const atk = this.pressedAttack(input);
        if (h.up) {
          // ジャンプ:離陸の瞬間に横方向の速度が決まる
          this.vy = P.jumpVelocity;
          this.vx = ((h.right ? 1 : 0) - (h.left ? 1 : 0)) * P.jumpSpeed;
          this.onGround = false;
          this.airAttackUsed = false;
          this.setState('jump');
        } else if (special) {
          this.startSpecial(special);
        } else if (atk) {
          this.startAttack((h.down ? 'crouch' : 'stand') + atk, 'attack');
        } else if (h.down) {
          this.vx = 0;
          this.setState('crouch');
        } else if (h.left !== h.right) {
          const dir = h.right ? 1 : -1;
          const forward = dir === this.facing;
          this.vx = dir * P.walkSpeed * (forward ? 1 : P.backwalkRatio);
          this.setState('walk');
        } else {
          this.vx = 0;
          this.setState('idle');
        }
      } else if (this.state === 'jump' && !this.airAttackUsed && this.stateFrame >= 1) {
        const atk = this.pressedAttack(input);
        if (atk) {
          this.airAttackUsed = true;
          this.startAttack('jump' + atk, 'jumpattack');
        }
      }

      if (!this.onGround) this.stepAir();
      else this.moveX(this.vx);
    }

    // 押した瞬間のボタン。'Punch' / 'Kick' / null
    pressedAttack(input) {
      if (input.pressed.punch) return 'Punch';
      if (input.pressed.kick) return 'Kick';
      return null;
    }

    // パンチを押した瞬間に、直近の入力が必殺技のコマンドになっていれば技名を返す
    detectSpecial(input) {
      if (!input.pressed.punch) return null;
      const H = Game.Core.InputHistory;
      const C = Game.Config.input.commands;
      if (H.match(this.index, this.facing, C.uppercut)) return 'uppercut';
      // 飛び道具は同時に1発まで
      if (Game.Logic.Projectile.countFor(this) === 0 && H.match(this.index, this.facing, C.fireball)) return 'fireball';
      return null;
    }

    startAttack(name, state) {
      this.move = name;
      this.attackFrame = 0;
      this.hitDone = false;
      if (state === 'attack') this.vx = 0;
      this.setState(state);
    }

    startSpecial(name) {
      this.move = name;
      this.attackFrame = 0;
      this.hitDone = false;
      this.vx = 0;
      this.setState('special');
    }

    updateGroundAttack() {
      const m = this.moveData;
      this.attackFrame++;
      this.vx = 0;
      if (this.attackFrame >= m.startup + m.active + m.recovery) {
        this.move = null;
        this.setState('idle');
      }
    }

    // 必殺技:startup のフレームで飛び道具を出す/飛び上がる
    updateSpecial() {
      const m = this.moveData;
      this.attackFrame++;
      if (this.attackFrame === m.startup) {
        if (m.projectile) Game.Logic.Projectile.spawn(this, m.projectile);
        if (m.launch) {
          this.onGround = false;
          this.vy = m.launch.vy;
          this.vx = this.facing * m.launch.vx;
        }
      }
      if (!this.onGround) {
        this.stepAir();
        return;
      }
      this.vx = 0;
      if (this.attackFrame >= m.startup + m.active + m.recovery) {
        this.move = null;
        this.setState('idle');
      }
    }

    // 空中の物理(ジャンプ中・空中攻撃中・昇竜の上昇中)
    stepAir() {
      const P = Game.Config.physics;
      const floorY = Game.Config.display.floorY;
      this.vy += P.gravity;
      this.y += this.vy;
      this.moveX(this.vx);
      if (this.y >= floorY) {                 // 着地
        const m = this.moveData;
        this.y = floorY;
        this.vy = 0;
        this.vx = 0;
        this.onGround = true;
        if (this.state === 'special' && m && m.landRecovery) {
          this.stunFrames = m.landRecovery;   // 昇竜を外すと大きな着地硬直
          this.move = null;
          this.setState('landing');
        } else {
          this.move = null;
          this.setState('idle');
        }
      }
    }

    // のけぞり・ガード硬直・ダウン・起き上がり・KO
    updateDamaged() {
      const P = Game.Config.physics;
      const floorY = Game.Config.display.floorY;

      if (!this.onGround) {
        this.vy += P.gravity;
        this.y += this.vy;
        this.wallPush = this.moveX(this.vx);
        if (this.y >= floorY) {
          this.y = floorY;
          this.vy = 0;
          this.vx *= 0.5;
          this.onGround = true;
          this.setState(this.health <= 0 ? 'ko' : 'down');
        }
        return;
      }

      this.vx *= P.hitFriction;
      if (Math.abs(this.vx) < 0.05) this.vx = 0;
      this.wallPush = this.moveX(this.vx);

      if ((this.state === 'hitstun' || this.state === 'blockstun') && this.stateFrame >= this.stunFrames) {
        this.setState('idle');
      } else if (this.state === 'down' && this.stateFrame >= P.downFrames) {
        this.setState('getup');
      } else if (this.state === 'getup' && this.stateFrame >= P.getupFrames) {
        this.setState('idle');
      }
    }

    // この技をガードできるか。地上で後ろを押していて、技の高さに合った構えのときだけ可能
    canBlock(move) {
      if (!this.onGround || !this.backHeld) return false;
      const s = this.state;
      if (s !== 'idle' && s !== 'walk' && s !== 'crouch' && s !== 'blockstun') return false;
      if (move.level === 'low' && !this.downHeld) return false;     // 下段は立ちガード不可
      if (move.level === 'high' && this.downHeld) return false;     // 上段はしゃがみガード不可
      return true;
    }

    // 攻撃を受ける。move は技(または飛び道具)のデータ、dir は攻撃側の向き(1 or -1)
    // 戻り値:'block'(ガードした) / 'hit'(受けた)
    takeHit(move, dir) {
      const P = Game.Config.physics;

      if (this.canBlock(move)) {
        this.move = null;
        this.state = 'blockstun';
        this.stateFrame = 0;
        this.guardCrouch = this.downHeld;
        this.stunFrames = move.blockstun;
        this.vx = dir * move.blockKnockback;
        return 'block';
      }

      this.health = Math.max(0, this.health - move.damage);
      this.move = null;
      this.hitDone = false;
      this.state = 'hitstun';
      this.stateFrame = 0;

      const dead = this.health <= 0;
      if (dead || !this.onGround || move.knockdown) {
        // 空中で受けた・倒された・ダウンを奪う技を受けた場合は、吹き飛んで倒れる
        this.onGround = false;
        this.vy = dead ? P.koPop : P.airHitPop;
        this.vx = dir * move.knockback * (dead ? 1.6 : 1.2);
      } else {
        this.stunFrames = move.hitstun;
        this.vx = dir * move.knockback;
      }
      return 'hit';
    }

    // 横に動く。画面端で動けなかった分を返す
    moveX(dx) {
      const P = Game.Config.physics;
      const half = P.bodyWidth / 2;
      const before = this.x;
      this.x = Math.max(P.stageLeft + half, Math.min(P.stageRight - half, before + dx));
      return dx - (this.x - before);
    }

    clampToStage() {
      this.moveX(0);
    }

    // 描画側が使う「どのポーズの何コマ目か」
    pose() {
      const A = Game.Config.display.anim;
      switch (this.state) {
        case 'walk': return { name: 'walk', frame: Math.floor(this.stateFrame / A.walk) };
        case 'jump': return { name: 'jump', frame: 0 };
        case 'crouch': return { name: 'crouch', frame: 0 };
        case 'attack':
        case 'jumpattack':
        case 'special': {
          const m = this.moveData;
          const t = this.attackFrame;
          const phase = t < m.startup ? 0 : (t < m.startup + m.active ? 1 : 2);
          return { name: this.move, frame: phase };
        }
        case 'landing': return { name: 'uppercutLand', frame: 0 };
        case 'hitstun': return { name: 'hit', frame: 0 };
        case 'blockstun': return { name: this.guardCrouch ? 'crouchGuard' : 'guard', frame: 0 };
        case 'down': case 'ko': return { name: 'down', frame: 0 };
        case 'getup': return { name: 'crouch', frame: 0 };
        default: return { name: 'idle', frame: Math.floor(this.stateFrame / A.idle) };
      }
    }
  }

  Game.Logic.Fighter = Fighter;
})();
