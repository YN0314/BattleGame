// ステージ「夜の街」の背景。起動時に1枚の画像へ描き出して使い回す。
(function () {
  'use strict';

  // 毎回同じ絵になる疑似乱数
  function rng(seed) {
    let s = seed >>> 0;
    return function () {
      s = (s * 1664525 + 1013904223) >>> 0;
      return s / 4294967296;
    };
  }

  function lerp(a, b, t) { return Math.round(a + (b - a) * t); }
  function mix(c1, c2, t) {
    return 'rgb(' + lerp(c1[0], c2[0], t) + ',' + lerp(c1[1], c2[1], t) + ',' + lerp(c1[2], c2[2], t) + ')';
  }

  function build() {
    const D = Game.Config.display;
    const W = D.width, H = D.height, F = D.floorY;
    const cv = document.createElement('canvas');
    cv.width = W; cv.height = H;
    const ctx = cv.getContext('2d');
    const rand = rng(7);

    // 空:段々になった色の帯(ドット絵らしい見た目)
    const top = [8, 10, 34], bottom = [58, 52, 110];
    const bands = 12;
    const bandH = Math.ceil(F / bands);
    for (let i = 0; i < bands; i++) {
      ctx.fillStyle = mix(top, bottom, i / (bands - 1));
      ctx.fillRect(0, i * bandH, W, bandH);
    }

    // 星
    for (let i = 0; i < 46; i++) {
      const x = Math.floor(rand() * W), y = Math.floor(rand() * (F * 0.55));
      ctx.fillStyle = rand() < 0.3 ? '#ffffff' : '#9fa6d8';
      ctx.fillRect(x, y, 1, 1);
    }

    // 月(三日月)
    const mx = 300, my = 40, mr = 13;
    for (let y = -mr; y <= mr; y++) {
      for (let x = -mr; x <= mr; x++) {
        const inMoon = x * x + y * y <= mr * mr;
        const inCut = (x - 5) * (x - 5) + (y + 2) * (y + 2) <= (mr - 1) * (mr - 1);
        if (inMoon && !inCut) { ctx.fillStyle = '#f4efc8'; ctx.fillRect(mx + x, my + y, 1, 1); }
      }
    }

    // 遠くのビル(窓の明かり付き)
    function buildings(color, minH, maxH, minW, maxW, windows) {
      let x = -4;
      while (x < W) {
        const w = Math.floor(minW + rand() * (maxW - minW));
        const h = Math.floor(minH + rand() * (maxH - minH));
        ctx.fillStyle = color;
        ctx.fillRect(x, F - h, w, h);
        if (windows) {
          for (let wy = F - h + 5; wy < F - 6; wy += 6) {
            for (let wx = x + 3; wx < x + w - 4; wx += 5) {
              if (rand() < 0.32) {
                ctx.fillStyle = rand() < 0.7 ? '#f6d36b' : '#8fd6f0';
                ctx.fillRect(wx, wy, 2, 3);
              }
            }
          }
        }
        x += w + Math.floor(rand() * 3);
      }
    }
    buildings('#1b1d46', 70, 130, 22, 38, true);
    buildings('#101230', 28, 70, 20, 40, false);

    // 地面
    ctx.fillStyle = '#2b2540';
    ctx.fillRect(0, F, W, H - F);
    ctx.fillStyle = '#4d4468';
    ctx.fillRect(0, F, W, 2);
    ctx.fillStyle = '#1d1830';
    ctx.fillRect(0, F + 16, W, 1);
    ctx.fillStyle = '#3a3252';
    for (let x = 0; x < W; x += 32) ctx.fillRect(x, F + 5, 14, 1);
    for (let x = 16; x < W; x += 32) ctx.fillRect(x, F + 22, 14, 1);

    return cv;
  }

  Game.Render.Background = { build: build };
})();
