// キャラクターの定義。技そのものは moves.config.js(技ライブラリ)にあり、ここでは「どの技を使うか」を決める。
//   name       : 表示名
//   sprite     : 見た目の種類(palettes.js の Game.Data.Looks のキー。'hero' = 道着、'nakagawa' = ワイシャツ姿)
//   body       : 体の数値の上書き(physics.config.js の項目名。書かなければ共通の値)
//   normals    : 通常技の割り当て。左=技の枠(ポーズ名と同じ)、右=技ライブラリの技名
//   normals の throw: 投げ技(書かなければそのキャラは投げられない)
//   specials   : 使える必殺技(技ライブラリの技名)。コマンドが重なる場合は先に書いたものを優先
//   overrides  : 技の数値の上書き。{ 技名: { 項目: 値 } }(同じ技でもこのキャラだけ威力を変える、など)
//                projectile の中の項目は { projectile: { damage: 12 } } のように書く
Game.Config.characters = {
  order: ['hero', 'nakagawa', 'hero_sheet'],     // 選択画面に並べる順

  hero: {
    name: 'HERO',
    sprite: 'hero',
    body: {},
    normals: {
      standPunch: 'standPunch', standKick: 'standKick',
      crouchPunch: 'crouchPunch', crouchKick: 'crouchKick',
      jumpPunch: 'jumpPunch', jumpKick: 'jumpKick',
      throw: 'throw'
    },
    specials: ['superfireball', 'flashkick', 'uppercut', 'slam', 'fireball', 'sonic'],   // slam は ←↓→ を含むため fireball より先
    overrides: {}
  },

  // 写真(ワイシャツ・ネクタイ・スラックス・眼鏡)をもとにしたキャラ。技は今のところヒーローと同じ
  nakagawa: {
    name: 'NAKAGAWA',
    sprite: 'nakagawa',
    body: {},
    normals: {
      standPunch: 'standPunch', standKick: 'standKick',
      crouchPunch: 'crouchPunch', crouchKick: 'crouchKick',
      jumpPunch: 'jumpPunch', jumpKick: 'jumpKick',
      throw: 'throw'
    },
    specials: ['superfireball', 'flashkick', 'uppercut', 'slam', 'fireball', 'sonic'],
    overrides: {}
  },

  // 画像(スプライトシート)で動くことの確認用サンプル。ヒーローの絵を画像に書き出したもので、技はヒーローと同じ。
  // 不要なら、この定義と order の 'hero_sheet'、palettes.js の hero_sheet を消してよい
  hero_sheet: {
    name: 'HERO SHEET',
    sprite: 'hero_sheet',
    body: {},
    normals: {
      standPunch: 'standPunch', standKick: 'standKick',
      crouchPunch: 'crouchPunch', crouchKick: 'crouchKick',
      jumpPunch: 'jumpPunch', jumpKick: 'jumpKick',
      throw: 'throw'
    },
    specials: ['superfireball', 'flashkick', 'uppercut', 'slam', 'fireball', 'sonic'],
    overrides: {}
  }
};
