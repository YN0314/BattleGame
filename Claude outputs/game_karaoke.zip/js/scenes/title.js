// タイトル画面。最初に「ボタンを押してください」→ モード選択。
//   stage 'press' : ボタン待ち(ここで押されたキー操作が、のちに音を鳴らす許可にもなる)
//   stage 'menu'  : 「VS 2P」「VS CPU」を選ぶ
//   stage 'level' : CPUの強さ(EASY / NORMAL)を選ぶ
//   stage 'chars' : キャラクターを選ぶ(2Pは1P→2Pの順。CPU戦は1Pだけ選び、CPUは別のキャラになる)
(function () {
  'use strict';

  function blank() {
    return { up: false, down: false, left: false, right: false, punch: false, kick: false, start: false };
  }
  const NEUTRAL = { held: blank(), pressed: blank() };

  const Title = {
    view: 'title',
    fighters: [],
    stage: 'press',
    index: 0,
    frame: 0,

    // メニュー項目。enabled が false の項目は選べない(CPUは実装されるまで)
    items: function () {
      return [
        { label: 'VS 2P', enabled: true, mode: '2p' },
        { label: 'VS CPU', enabled: !!Game.Logic.AI, mode: 'cpu' }
      ];
    },

    levelItems: function () {
      return Game.Logic.AI.levels().map(function (k) {
        return { label: Game.Config.ai.levels[k].label, level: k };
      });
    },

    // 背景で立っている2人を作り直す(キャラ選択中は、選択中のキャラを見せる)
    setFighters: function (c0, c1) {
      const F = Game.Logic.Fighter;
      const W = Game.Config.display.width;
      this.fighters = [
        new F({ index: 0, x: W * 0.22, facing: 1, palette: 0, character: c0 }),
        new F({ index: 1, x: W * 0.78, facing: -1, palette: 1, character: c1 })
      ];
    },

    // キャラ選択を始める。mode: '2p' | 'cpu'
    startPick: function (mode, level) {
      this.pickMode = mode;
      this.pickLevel = level;
      this.pickSide = 0;                 // 0:1P が選ぶ / 1:2P が選ぶ
      this.picked = [];
      this.charIndex = 0;
      this.stage = 'chars';
      this.previewChar();
    },

    previewChar: function () {
      const ids = Game.Logic.Character.ids();
      const cur = ids[this.charIndex];
      const first = this.picked[0] || ids[0];
      if (this.pickSide === 0) this.setFighters(cur, this.picked[1] || ids[0]);
      else this.setFighters(first, cur);
    },

    enter: function () {
      this.setFighters();
      Game.Logic.Projectile.reset();
      Game.Render.Effects.reset();
      Game.Render.UI.reset();
      this.stage = 'press';
      this.index = 0;
      this.levelIndex = 1;
      this.frame = 0;
    },

    update: function () {
      const SM = Game.Core.SceneManager;
      Game.Core.Input.update();
      Game.Render.Effects.update();
      this.frame++;
      this.fighters[0].update(NEUTRAL, this.fighters[1]);
      this.fighters[1].update(NEUTRAL, this.fighters[0]);

      const nav = SM.nav();
      if (this.stage === 'press') {
        if (nav.confirm || nav.back) { this.stage = 'menu'; this.frame = 0; Game.Core.Sound.play('ok'); }
        return;
      }

      if (this.stage === 'chars') {
        const ids = Game.Logic.Character.ids();
        const m = ids.length;
        if (nav.up || nav.down) {
          this.charIndex = (this.charIndex + (nav.down ? 1 : m - 1)) % m;
          Game.Core.Sound.play('move');
          this.previewChar();
        }
        if (nav.back) {
          Game.Core.Sound.play('back');
          if (this.pickSide === 1) { this.pickSide = 0; this.charIndex = ids.indexOf(this.picked[0]); this.picked = []; this.previewChar(); }
          else { this.stage = this.pickMode === 'cpu' ? 'level' : 'menu'; this.setFighters(); }
        } else if (nav.confirm) {
          Game.Core.Sound.play('ok');
          this.picked[this.pickSide] = ids[this.charIndex];
          if (this.pickMode === 'cpu') {
            const others = ids.filter(function (id) { return id !== ids[Title.charIndex]; });
            const pool = others.length ? others : ids;      // CPU は選んだキャラ以外から(いなければ同じキャラ)
            SM.go('battle', { mode: 'cpu', level: this.pickLevel, chars: [ids[this.charIndex], pool[Math.floor(Math.random() * pool.length)]] });
          } else if (this.pickSide === 0) {
            this.pickSide = 1; this.charIndex = 0; this.previewChar();
          } else {
            SM.go('battle', { mode: '2p', chars: [this.picked[0], this.picked[1]] });
          }
        }
        return;
      }

      if (this.stage === 'level') {
        const lv = this.levelItems();
        const m = lv.length;
        if (nav.up) { this.levelIndex = (this.levelIndex + m - 1) % m; Game.Core.Sound.play('move'); }
        if (nav.down) { this.levelIndex = (this.levelIndex + 1) % m; Game.Core.Sound.play('move'); }
        if (nav.back) { this.stage = 'menu'; Game.Core.Sound.play('back'); }
        else if (nav.confirm) { Game.Core.Sound.play('ok'); Title.startPick('cpu', lv[this.levelIndex].level); }
        return;
      }

      const items = this.items();
      const n = items.length;
      const move = function (dir) {
        for (let k = 1; k <= n; k++) {
          const j = (Title.index + dir * k + n * 2) % n;
          if (items[j].enabled) { Title.index = j; return; }
        }
      };
      if (nav.up) { move(-1); Game.Core.Sound.play('move'); }
      if (nav.down) { move(1); Game.Core.Sound.play('move'); }
      if (nav.back) { this.stage = 'press'; Game.Core.Sound.play('back'); return; }
      if (nav.confirm && items[this.index].enabled) {
        Game.Core.Sound.play('ok');
        if (items[this.index].mode === 'cpu') { this.stage = 'level'; return; }
        Title.startPick('2p'); return;
      }
    },

    render: function () {
      Game.Render.Renderer.draw(this);
    }
  };

  Game.Scenes.Title = Title;
  Game.Core.SceneManager.register('title', Title);
})();
