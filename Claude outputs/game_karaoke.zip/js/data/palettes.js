// キャラの配色。1P・2Pはこの色だけが違う。
// キー: s=肌, S=肌の影, h=髪, g=道着, G=道着の影, b=帯, k=鉢巻, w=手の巻き布, o=輪郭線, e=目
Game.Data.Palettes = [
  // 1P:白い道着、黒帯、赤い鉢巻
  { s: '#f2b88f', S: '#cf8e68', h: '#2b1b16', g: '#f5f5f0', G: '#bcc0cf', b: '#1b1b22',
    k: '#d8443a', w: '#e9e2cf', o: '#16121f', c: '#9a6a36', C: '#6a4522', e: '#16121f' },
  // 2P:赤い道着、黄帯、白い鉢巻
  { s: '#d99a6c', S: '#b0744b', h: '#8c2a18', g: '#d8443a', G: '#9a2b2c', b: '#f2c230',
    k: '#f4f4ee', w: '#f4f4ee', o: '#16121f', c: '#9a6a36', C: '#6a4522', e: '#16121f' }
];

// 見た目の種類(look)。style は体の描き方(sprites.js)、palettes は [1P色, 2P色]。
//   karate : 道着(ヒーロー)
//   sheet  : 画像のスプライトシート(sheet = Game.Data.Sheets のキー、fallback = 読み込めないときの見た目)
//   shirt  : ワイシャツ・ネクタイ・スラックス(写真から作ったキャラ)
// キー(shirt): s/S=肌 h=髪 g/G=シャツ t/T=スラックス n/N=ネクタイ b=ベルト m=バックル x=靴 f=眼鏡 w=未使用 k=未使用 o=輪郭 e=目
Game.Data.Looks = {
  hero: { style: 'karate', palettes: Game.Data.Palettes },
  nakagawa: {
    style: 'shirt',
    palettes: [
      // 1P:白シャツ、濃紺のネクタイ、黒いスラックス
      { s: '#efc29c', S: '#c99772', h: '#17171d', g: '#f6f7f9', G: '#b4bfd0', t: '#383c4e', T: '#222532',
        n: '#27305a', N: '#4a5fa0', b: '#101015', m: '#b9bdc6', x: '#17171c', f: '#26262d',
        w: '#f6f7f9', k: '#17171d', o: '#14121c', c: '#9a6a36', C: '#6a4522', e: '#14121c' },
      // 2P:水色のシャツ、えんじのネクタイ、グレーのスラックス
      { s: '#e2b48d', S: '#b98a66', h: '#2a1d18', g: '#a9cdea', G: '#7499bd', t: '#5d6272', T: '#3e4250',
        n: '#8e2c3a', N: '#b94a58', b: '#1a1a20', m: '#d4c27a', x: '#222228', f: '#2b2b33',
        w: '#a9cdea', k: '#2a1d18', o: '#14121c', c: '#9a6a36', C: '#6a4522', e: '#14121c' }
    ]
  }
  ,
  // 画像(スプライトシート)の見た目。assets/ の画像と、その切り出し定義(Game.Data.Sheets の hero_sheet)を使う。
  // 作り方は assets/README.md。画像が読み込めないときは、道着の自動生成の絵に戻る。
  hero_sheet: { style: 'sheet', sheet: 'hero_sheet', fallback: 'hero', palettes: Game.Data.Palettes }
};
